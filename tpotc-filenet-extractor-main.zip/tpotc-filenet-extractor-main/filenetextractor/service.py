"""
The class that actually connects to the database, extracts data, and uploads to Cognite. # noqa: E501
"""

import logging
from time import localtime
from typing import Any

import arrow
import cronex

from cognite.extractorutils import Extractor

from filenetextractor import __version__
from filenetextractor.config import FilenetConfig, EndpointConfig
from filenetextractor.extractor import run_extractor


class ExtractorService(Extractor):
    """
    The class that wraps single execution run into service
    Args:
    """

    def __init__(  # type: ignore
        self,
        name="filenetextractor",
        description="Filenet extractor",
        config_class=FilenetConfig,
        run_handle=run_extractor,
        config_file_path="config.yaml",
        version=__version__,
    ) -> None:
        super(ExtractorService, self).__init__(
            name=name,
            description=description,
            config_class=config_class,
            run_handle=run_handle,
            config_file_path=config_file_path,
            version=version,
        )
        self._logger = logging.getLogger(__name__)
        self._utc_offset = arrow.now("local").utcoffset().seconds // 3600
   
    def _schedule_condition(self, config: EndpointConfig) -> bool:
        result = False
        if config.schedule is not None:
            try:
                result = self._check_schedule(config.schedule)
                if result:
                    self._logger.info(f"Triggering execution for Filenet extractor")
            except Exception as e:
                self._logger.error(f"Schedule check has failed for Filenet extractor", exc_info=True)
                raise e

        return result

    def _check_schedule(self, schedule: str) -> bool:
        exp = cronex.CronExpression(schedule)
        return exp.check_trigger(localtime()[:5], self._utc_offset)

    def _run(self) -> None:
        """
        Run service extractor
        """
        self._logger.info("Service is up and running with version " + str(__version__))
        while not self.cancelation_token.wait(timeout=(arrow.utcnow().ceil("minute") - arrow.utcnow()).total_seconds()):
            try:
                if self._schedule_condition(self.config):
                    self.run()  # plan threads for execution

            except Exception:
                logging.error("service execution has failed", exc_info=True)

        self._logger.warning("Stop event is set. Shutting down the service.")

    def __enter__(self):
        super(ExtractorService, self).__enter__()
        return self

    def __exit__(self, exc_type, exc_value, traceback: Any) -> bool:
        self.cancelation_token.set()  # for service implementation exit should set the intention
        return super(ExtractorService, self).__exit__(exc_type, exc_value, traceback)
