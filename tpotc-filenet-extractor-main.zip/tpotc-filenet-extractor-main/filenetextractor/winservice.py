import concurrent.futures
import logging
import os
import socket
import sys
from threading import Event
from typing import Optional

import servicemanager
import win32event
import win32evtlog
import win32evtlogutil
import win32service
import win32serviceutil
from cognite.extractorutils.configtools import InvalidConfigError, load_yaml

from filenetextractor import __version__
from filenetextractor.config import FilenetConfig
from filenetextractor.service import ExtractorService
from filenetextractor.extractor import run_extractor

service_name = "cognite_filenet_soap" 
service_display_name = "Cognite FILENET-SOAP extractor" 
service_description = "Cognite FILENET extractor with SOAP" 


class WindowsService(win32serviceutil.ServiceFramework):
    _svc_name_ = service_name
    _svc_display_name_ = service_display_name
    _svc_description_ = service_description

    @classmethod
    def parse_command_line(cls) -> None:
        win32serviceutil.HandleCommandLine(cls)

    def __init__(self, args: str) -> None:
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.hWaitStop = win32event.CreateEvent(None, 0, 0, None)
        socket.setdefaulttimeout(60)
        self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=5)
        self.stop_event = Event()

    def SvcStop(self) -> None:
        """Stop the service"""
        self.stop_event.set()
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self.hWaitStop)

    def SvcDoRun(self) -> None:
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STARTED,
            (self._svc_name_, ""),
        )
        os.chdir(os.path.dirname(sys.executable))
        config: FilenetConfig
        with open(os.path.join(os.path.dirname(sys.executable), "config.yaml"), "r") as stream:
            try:
                config = load_yaml(source=stream, config_type=FilenetConfig)

            except InvalidConfigError as e:
                servicemanager.LogMsg(
                    servicemanager.EVENTLOG_ERROR_TYPE,
                    servicemanager.PYS_SERVICE_STARTED,
                    (self._svc_name_, "Invalid config file {}".format(e)),
                )
                raise SystemExit(1)

            finally:
                stream.close()
        try:

            with ExtractorService(
                name="filenetextractor",
                description="Filenet extractor",
                config_class=FilenetConfig,
                run_handle=run_extractor,
                config_file_path='config.yaml',
                version=__version__,
            ) as extractor:
                extractor._run()

        except SystemExit as e:
            if e.code != 0:
                self.ReportServiceStatus(win32service.SERVICE_ERROR_CRITICAL)
            logging.error("Exiting...", exc_info=True)
            raise SystemExit(2)  # crash and notify service manager that something went wrong
        except Exception as e:
            logging.error(e, exc_info=True)
            error_event_log(f"Unexpected error during run: {e}")
            raise SystemExit(3)  # crash and notify service manager that something went wrong
       

def error_event_log(message: str, additional: Optional[str] = None):
    if additional is None:
        additional = ""

    win32evtlogutil.ReportEvent(
        service_name,
        0,
        eventType=win32evtlog.EVENTLOG_WARNING_TYPE,
        strings=message,
        data=additional.encode(),
    )

def init():
    if len(sys.argv) == 1:
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(WindowsService)
        servicemanager.StartServiceCtrlDispatcher()
    else:
        win32serviceutil.HandleCommandLine(WindowsService)

if __name__ == '__main__': 
        init()
