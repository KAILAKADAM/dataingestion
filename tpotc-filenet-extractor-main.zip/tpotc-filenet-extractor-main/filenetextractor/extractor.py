from datetime import datetime, timedelta
from logging import Logger, getLogger
from typing import Any, List, Union
from threading import Event 

import pandas as pd
from cognite.client import CogniteClient
from cognite.client.data_classes.raw import Row
from cognite.extractorutils.uploader import RawUploadQueue
from cognite.extractorutils.statestore import AbstractStateStore
from zeep import Client

from filenetextractor.config import File, FilenetConfig, SearchEndpointConfig

logger = getLogger(__name__)


def parseData(res: Any) -> File:
    propertiesDict = {}
    item = res.FnContent[0]

    for i in item["Properties"]["FnProperty"]:
        propertiesDict[i["IndexName"]] = i["IndexValue"]

    contentByte = item["ContentByte"]
    mimeType = item["MimeType"]
    propertiesDict["Extension"] = item["Extension"]
    propertiesDict["ClassName"] = item["ClassName"]
    tmp = item["CeId"].replace("{", "")
    propertiesDict["Filenet CeID"] = tmp.replace("}", "")
    externalId = propertiesDict["Filenet CeID"]

    if (not mimeType) and (propertiesDict["OwnerDocNumber"]):
        ownerDocNumer = propertiesDict["OwnerDocNumber"]
        mimeType = propertiesDict["MimeType"].split("/")[-1]
        name = ownerDocNumer + "." + mimeType
    else:
        name = propertiesDict["OwnerDocNumber"]

    file = File(
        contentByte=contentByte,
        mimeType=mimeType,
        name=name,
        metadata=propertiesDict,
        externalId=externalId,  # noqa: E501
    )  # noqa: E501

    return file


def queryProcessor(
    names: List[str], queryOperators: List[str], values: List[str], last_session: Any  # noqa: E501
) -> List[dict]:  # noqa: E501

    it = iter([names, queryOperators, values])
    the_len = len(next(it))
    if not all(len(l) == the_len for l in it):  # noqa: E741
        msg1 = "Make sure number of items in 'names', 'queryOperators' and "
        msg2 = "'values' from config.yaml are the same length"
        raise ValueError(msg1 + msg2)

    queryBody = []
    for name, queryOperator, value in zip(names, queryOperators, values):
        if name == "DateCreated":
            if value == "now":
                value_datetime = datetime.today()
            elif value == "last_session":
                value = last_session["last_successful_run_time [datetime]"].iloc[0]  # noqa: E501
                logger.info(f"Last Session: {value}")
                value = value.split(",")[0]
                value_datetime = datetime.strptime(value, "%m/%d/%Y") - timedelta(days=1)  # noqa: E501
            elif "d-ago" in value:
                days_ago = int(value.replace("d-ago", ""))
                value_datetime = datetime.today() - timedelta(days=days_ago)
            else:
                value_datetime = datetime.strptime(value, "%y/%m/%d")
    
            item = {"Name": name, "QueryOperator": queryOperator, "Value": value_datetime}  # noqa: E501
            
        else:
            item = {"Name": name, "QueryOperator": queryOperator, "Value": value} 
            
        queryBody.append(item)

    return queryBody


def newFiles(
    cogniteClient: CogniteClient,
    filenetClient: Any,
    requestHeader: dict,
    endpointConfig: SearchEndpointConfig,
    cogniteDatasetId: str,
    last_session: pd.DataFrame,
    logger: Logger,
) -> List[str]:

    queryBody = queryProcessor(
        endpointConfig.name, endpointConfig.queryOperator, endpointConfig.value, last_session  # noqa: E501
    )  # noqa: E501

    res = filenetClient.service.SearchContentByProperty(
        requestHeader=requestHeader,
        maxRecords=endpointConfig.maxRecords,
        className=endpointConfig.className,
        searchCriteria={"FnSearchCriteria": queryBody},
        orderBy="DateCreated",
        isDecending=False,
    )

    fileIds = []
    for file in res.Contents.FnContent:
        tmp = file["CeId"]
        tmp = tmp.replace("{", "")
        tmp = tmp.replace("}", "")
        fileIds.append(tmp)
        logger.info(f"{tmp} recieved")

    cdfFiles = cogniteClient.files.list(data_set_ids=[int(cogniteDatasetId)], limit=-1)  # noqa: E501
    cdfFileIds = [i.external_id for i in cdfFiles]

    newFileIds = [id for id in fileIds if id not in cdfFileIds]
    excludedIds = [id for id in fileIds if id in cdfFileIds]

    for id in excludedIds:
        logger.info(f"{id} exists in CDF. File not uploaded.")

    logger.info(
        f"{len(excludedIds)} files already in CDF out of {len(fileIds)} from query ({len(excludedIds)/len(fileIds)*100:.1f}%)."  # noqa: E501
    )
    logger.info(
        f"{len(newFileIds)} new files out of {len(fileIds)} from query ({len(newFileIds)/len(fileIds)*100:.1f}%)."  # noqa: E501
    )

    return newFileIds


def getContent(  # type: ignore
    filenetClient: Any,
    requestHeader: dict,
    fileId: str,
    logger: Logger,
) -> Union[File, None]:

    res = filenetClient.service.GetContent(requestHeader=requestHeader, contentEngineId=fileId)  # noqa: E501

    resCode = res["ResultCode"]
    resMessage = res["ResultMessage"]
    content = res["Contents"]

    if resCode == "2":
        resMessage = f"{resMessage}: {fileId}"
        logger.error(resMessage)
    elif resCode == "1":
        resMessage = f"{resMessage}: {fileId}"
        logger.error(resMessage)
    else:
        resGetContent = parseData(content)
        logger.info(f"{fileId} contents retrieved.")

        return resGetContent


def uploadFile(
    cogniteClient: CogniteClient,
    file: File,
    logger: Logger,
    cogniteDatasetId: str,
) -> None:
    # try:
    cogniteClient.files.upload_bytes(
        content=file.contentByte,
        name=file.name,
        metadata=file.metadata,
        data_set_id=int(cogniteDatasetId),
        mime_type=file.mimeType,
        external_id=file.externalId,
    )
    logger.info(f"{file.metadata['Filenet CeID']} uploaded to CDF.")


def last_sessions_state(cognite: CogniteClient, config: FilenetConfig) -> pd.DataFrame:  # noqa: E501
    database = config.cdf_sessions_state.database
    table = config.cdf_sessions_state.table

    df = cognite.raw.rows.retrieve_dataframe(database, table)

    return df


def upload_sessions_state(cognite: CogniteClient, config: FilenetConfig) -> None:  # noqa: E501
    time = datetime.now()
    time_string = time.strftime("%m/%d/%Y, %H:%M:%S")
    time_epoch = time.timestamp() * 1000
    data = {
        "key": "last_run",
        "last_successful_run_time [epoch]": time_epoch,
        "last_successful_run_time [datetime]": time_string,
    }
    with RawUploadQueue(cdf_client=cognite, max_queue_size=100_000) as queue:
        queue.add_to_upload_queue(
            database=config.cdf_sessions_state.database,
            table=config.cdf_sessions_state.table,
            raw_row=Row(key=data["key"], columns=data),
        )

    logger.info("Uploaded last sessions state.")


def run_extractor(
    cogniteClient: CogniteClient,
    states: AbstractStateStore,
    config: FilenetConfig, 
    stop_event: Event
    ) -> None:

    logger.info("Initiate filenet extractor.")
    filenetClient = Client(config.endpoint.url)
    logger.info("Filenet client initialized.")

    requestHeader = {"UserName": config.auth.username, "Password": config.auth.password}  # noqa: E501

    last_session = last_sessions_state(cogniteClient, config)

    # Query for new files using SearchContentByProperty endpoint
    logger.info("Start search for new files")
    msg1 = f"Search query: \n Name: {config.endpoint.searchEndpoint.name} "
    msg2 = f"\n Query Operator: {config.endpoint.searchEndpoint.queryOperator} "  # noqa: E501
    msg3 = f"\n Value: {config.endpoint.searchEndpoint.value} "
    msg4 = f"\n Order By: {config.endpoint.searchEndpoint.orderBy} "
    msg5 = f"\n Is Decending: {config.endpoint.searchEndpoint.isDescending}"
    logger.info(msg1 + msg2 + msg3 + msg4 + msg5)
    fileIds = newFiles(
        cogniteClient,
        filenetClient,
        requestHeader,
        config.endpoint.searchEndpoint,
        config.cogniteDatasetId,
        last_session,
        logger,
    )
    logger.info("Finish search for new files")

    for fileIdx, fileId in enumerate(fileIds):
        logger.info(
            f"Start process of get content and upload to CDF for file: {fileId} ({fileIdx/len(fileIds)*100:.1f}%)."  # noqa: E501
        )
        file = getContent(filenetClient, requestHeader, fileId, logger)

        if not file:
            continue

        # Upload Files to CDF
        uploadFile(cogniteClient, file, logger, config.cogniteDatasetId)

    upload_sessions_state(cogniteClient, config)

    logger.info("Finish upload files to CDF")

    logger.info("Extraction complete")
