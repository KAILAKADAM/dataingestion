from dataclasses import dataclass
from typing import List, Optional

from cognite.extractorutils.configtools import BaseConfig, MetricsConfig, StateStoreConfig


@dataclass
class File:
    contentByte: str
    mimeType: str
    name: str
    metadata: dict
    externalId: str


@dataclass
class ExtractorConfig:
    state_store: StateStoreConfig = StateStoreConfig()


@dataclass
class FilenetAuthConfig:
    """
    Credentials for use with Filenet endpoint
    """

    username: str
    password: str
    schedule: Optional[str] = None  # Global specific config


@dataclass
class SearchEndpointConfig:
    """
    Specification for SearchContentByProperty endpoint
    """

    className: str
    name: List[str]
    queryOperator: List[str]
    value: List[str]
    maxRecords: int
    orderBy: str
    isDescending: bool


@dataclass
class EndpointConfig:
    """
    Specification of each SOAP endpoint to query
    """

    url: str
    searchEndpoint: SearchEndpointConfig


@dataclass
class CDFSessionsStateConfig:
    """
    Sessions state of extractor hosted in CDF Raw
    """

    database: str
    table: str


@dataclass
class FilenetConfig(BaseConfig):
    """
    Master configuration class, containing everything
    from the BaseConfig class, in addition to the custom
    building blocks defined above
    """

    auth: FilenetAuthConfig
    endpoint: EndpointConfig
    cogniteDatasetId: str
    # storage: StorageConfig
    cdf_sessions_state: CDFSessionsStateConfig
    extractor: ExtractorConfig = ExtractorConfig()
    metrics: Optional[MetricsConfig] = None
    schedule: Optional[str] = None  # query specific config

