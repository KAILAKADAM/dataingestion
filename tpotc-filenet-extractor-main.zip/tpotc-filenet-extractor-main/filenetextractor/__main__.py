from filenetextractor import __version__
from filenetextractor.config import FilenetConfig
from filenetextractor.extractor import run_extractor
from filenetextractor.service import ExtractorService


def main() -> None:
    with ExtractorService(
        name="filenetextractor",
        description="Filenet extractor",
        config_class=FilenetConfig,
        run_handle=run_extractor,
        config_file_path="config.yaml",
        version=__version__,
    ) as extractor:
        extractor._run()


if __name__ == "__main__":
    main()
